<?php

/* @Page:/Volumes/SVN/sites/kb-grav/user/pages/02.theme/01.topic-1 */
class __TwigTemplate_2c7d39f1e0c28e6c2151aeabf4127df2346b77b2eae4b9b49c799570f671cf04 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<p>Lorem markdownum murmure fidissime suumque. Nivea agris, duarum longaeque Ide
rugis Bacchum patria tuus dea, sum Thyneius liquor, undique. <strong>Nimium</strong> nostri
vidisset fluctibus <strong>mansit</strong> limite rigebant; enim satis exaudi attulit tot
lanificae <a href=\"http://www.mozilla.org/\">indice</a> Tridentifer laesum. Movebo et fugit,
limenque per ferre graves causa neque credi epulasque isque celebravit pisces.</p>
<ul>
<li>Iasone filum nam rogat</li>
<li>Effugere modo esse</li>
<li>Comminus ecce nec manibus verba Persephonen taxo</li>
<li>Viribus Mater</li>
<li>Bello coeperunt viribus ultima fodiebant volentem spectat</li>
<li>Pallae tempora</li>
</ul>
<h2>Fuit tela Caesareos tamen per balatum</h2>
<p>De obstruat, cautes captare Iovem dixit gloria barba statque. Purpureum quid
puerum dolosae excute, debere prodest <strong>ignes</strong>, per Zanclen pedes! <em>Ipsa ea
tepebat</em>, fiunt, Actoridaeque super perterrita pulverulenta. Quem ira gemit
hastarum sucoque, idem invidet qui possim mactatur insidiosa recentis, <strong>res
te</strong> totumque <a href=\"http://tumblr.com/\">Capysque</a>! Modo suos, cum parvo coniuge, iam
sceleris inquit operatus, abundet <strong>excipit has</strong>.</p>
<p>In locumque <em>perque</em> infelix hospite parente adducto aequora Ismarios,
feritatis. Nomine amantem nexibus te <em>secum</em>, genitor est nervo! Putes
similisque festumque. Dira custodia nec antro inornatos nota aris, ducere nam
genero, virtus rite.</p>
<ul>
<li>Citius chlamydis saepe colorem paludosa territaque amoris</li>
<li>Hippolytus interdum</li>
<li>Ego uterque tibi canis</li>
<li>Tamen arbore trepidosque</li>
</ul>
<h2>Colit potiora ungues plumeus de glomerari num</h2>
<p>Conlapsa tamen innectens spes, in Tydides studio in puerili quod. Ab natis non
<strong>est aevi</strong> esse riget agmenque nutrit fugacis.</p>
<ul>
<li>Coortis vox Pylius namque herbosas tuae excedere</li>
<li>Tellus terribilem saetae Echinadas arbore digna</li>
<li>Erraverit lectusque teste fecerat</li>
</ul>
<p>Suoque descenderat illi; quaeritur ingens cum periclo quondam flaventibus onus
caelum fecit bello naides ceciderunt cladis, enim. Sunt aliquis.</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/Volumes/SVN/sites/kb-grav/user/pages/02.theme/01.topic-1";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
