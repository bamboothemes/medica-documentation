<?php

/* partials/logo.html.twig */
class __TwigTemplate_880de8fe27a04d5d94ed9681eb0a34cb0730e8509b77dbee2f6bfc6d91175acc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "partials/logo.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
