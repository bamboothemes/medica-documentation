<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'user/config/plugins/simplesearch.yaml',
    'modified' => 1439346820,
    'data' => [
        'enabled' => true,
        'built_in_css' => false,
        'route' => '/search',
        'template' => 'simplesearch_results',
        'filters' => [
            'category' => 'docs'
        ]
    ]
];
