<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'user/plugins/highlight/highlight.yaml',
    'modified' => 1439346820,
    'data' => [
        'enabled' => true,
        'theme' => 'default'
    ]
];
