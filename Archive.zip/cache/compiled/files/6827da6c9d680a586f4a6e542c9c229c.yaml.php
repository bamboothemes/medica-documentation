<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'system/blueprints/config/media.yaml',
    'modified' => 1439346820,
    'data' => [
        'title' => 'Media',
        'form' => [
            'validation' => 'loose',
            'fields' => NULL
        ]
    ]
];
