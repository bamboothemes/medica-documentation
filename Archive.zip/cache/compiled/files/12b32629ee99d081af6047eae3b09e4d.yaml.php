<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'user/plugins/problems/problems.yaml',
    'modified' => 1439346822,
    'data' => [
        'enabled' => true,
        'built_in_css' => true
    ]
];
