<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'system/blueprints/config/streams.yaml',
    'modified' => 1439346820,
    'data' => [
        'title' => 'File Streams',
        'form' => [
            'validation' => 'loose',
            'fields' => [
                'schemes.xxx' => [
                    'type' => 'array'
                ]
            ]
        ]
    ]
];
