<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'user/localhost/config/system.yaml',
    'modified' => 1439346820,
    'data' => [
        'assets' => [
            'css_pipeline' => false,
            'js_pipeline' => false
        ],
        'twig' => [
            'cache' => true,
            'debug' => true
        ],
        'debugger' => [
            'enabled' => false
        ]
    ]
];
