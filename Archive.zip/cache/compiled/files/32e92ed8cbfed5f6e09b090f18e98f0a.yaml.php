<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'user/config/plugins/highlight.yaml',
    'modified' => 1439346820,
    'data' => [
        'theme' => 'learn'
    ]
];
