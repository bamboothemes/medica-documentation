<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'user/config/plugins/anchors.yaml',
    'modified' => 1439346820,
    'data' => [
        'selectors' => '#body h2, #body h3, #body h4, #body h5'
    ]
];
