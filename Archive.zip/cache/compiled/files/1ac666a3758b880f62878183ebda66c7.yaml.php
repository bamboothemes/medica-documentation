<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'user/config/site.yaml',
    'modified' => 1443343037,
    'data' => [
        'title' => 'Medica Joomla Template Documentation',
        'metadata' => [
            'description' => 'Medica Joomla Template Documentation'
        ],
        'taxonomies' => [
            0 => 'category',
            1 => 'tag'
        ],
        'summary' => [
            'size' => 300
        ]
    ]
];
