# v1.1.0
## 07/19/2015

1. [](#new)
    * Added search highlight support
    * Added a footer

# v1.0.1
## 06/2/2015

1. [](#new)
    * Added support for 2+ page levels

# v1.0.0
## 06/17/2015

1. [](#new)
    * ChangeLog started...
