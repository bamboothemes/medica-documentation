---
title: Logo font color
taxonomy:
    category: docs
---


The color of the text used in the logo custom html position is controlled via the template settings under the theme panel.

## Navigate to the theme panel
![ZGFv4 Theme Panel](/images/logo/theme-panel.png)
 
 
## Set the logo color and the hover color to use if the logo text is also a link
![Logo Font Color](/images/logo/logo-color.png)
 