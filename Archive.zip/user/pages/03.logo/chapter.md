---
title: Logo
taxonomy:
    category: docs
---

# Logo Overview 

![Logo Font Color](/images/logo/logo-display.jpg)
 


The logo in all Zen Grid Framework v4 themes is displayed via a custom html module published to the logo module position.

This section outlines the markup required to recreate the display seen in the demo site as well as how to control the font size and color.