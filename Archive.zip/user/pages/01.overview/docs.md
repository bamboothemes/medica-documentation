---
title: Medica Overview
menu: Overview
taxonomy:
    category: docs
---

![Alt text](http://www.joomlabamboo.com/images/new/medica/medica.jpg 'Medica Joomla Template')

Let Medica take care of your website while you care for others. Medica is an elegant and health oriented business theme with a tonne of class and style.         
 
[Features](http://www.joomlabamboo.com/joomla-templates/medica) / [Download](http://www.joomlabamboo.com/downloads/template-downloads?param=medica) / [Support Forum](http://www.joomlabamboo.com/index.php?option=com_kunena&view=category&catid=687&Itemid=215)

Theme Requirements
----

Joomla 3+

Getting Started with Joomla tutorials
----

- <a href="/getting-started/how-to-install-a-joomla-template">How to install a Joomla template</a>
- <a href="/getting-started/how-to-install-a-joomla-3-quickstart-package">How to install the quickstart package</a>
- <a href="http://docs.joomlabamboo.com/getting-started/how-to-install-a-joomla-module">How to install a Joomla extension</a>


Getting Started with the zen grid framework v4
----

Medica is built using the Zen Grid Framework v4. You can see the documentation for Zen Grid Framework v4 on the <a href="/zen-grid-framework-4/">ZGFv4 dedicated knowledgebase</a>.