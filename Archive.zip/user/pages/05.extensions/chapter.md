---
title: Extensions
taxonomy:
    category: docs
---

# Extensions used on the demo site

- Zentools2 (module + 2 plugins installed via a package)
- Zenmenu (plugin)
- Zen Shortcodes (plugin)
- Maps2 (module)
