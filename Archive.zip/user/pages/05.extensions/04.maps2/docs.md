---
title: Maps2
taxonomy:
    category: docs
---


#### What is this?
Maps2 is a module used to display a google map in a module.


- <a href="http://www.joomlabamboo.com/joomla-extensions/maps2">Features</a>
- <a href="http://joomlabamboo.com/index.php?option=com_docman&task=doc_download&gid=677&Itemid=">Download</a>
- <a href="http://docs.joomlabamboo.com/joomla-extensions/jb-maps2-documentation">Documentation</a>




#### Where is it used on the demo?
The maps2 module can be seen on the demo site in two places:
- in the banner position for the <a href="http://bambootheme.com/showcase/sep15/joomla/single-contact">contact page</a>

![Maps2 Contact](/images/maps/Medica-Contact.jpg)

- in the bottom1 position on the <a href="http://bambootheme.com/showcase/sep15/">front page</a> with the title Finding us.

![Maps2 Frontpage](/images/maps/map-frontpage.jpg)
 




