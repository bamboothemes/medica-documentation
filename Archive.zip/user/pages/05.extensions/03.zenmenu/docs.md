---
title: Zenmenu
taxonomy:
    category: docs
---

Zenmenu is a plugin that adds mega menu functionality to your ZGF4 menu.
- <a href="http://joomlabamboo.com/index.php?option=com_docman&task=doc_download&gid=694&Itemid=">Download</a>
- <a href="http://docs.joomlabamboo.com/zen-grid-framework-4/menus/Zen-menu-plugin">Documentation</a>

Zenmenu is used to add icons, subtitles, group and multiple columns to menu items.

![Zenmenu](/images/zenmenu/zenmenu.jpg)
 


