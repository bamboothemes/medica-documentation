---
title: Changing background color for specific rows
taxonomy:
    category: docs
---

## Coming soon