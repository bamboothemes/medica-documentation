---
title: Hidden Panel
taxonomy:
    category: docs
---

The hidden panel is a module position that sits on top of the page in a modal window after the user clicks on the hidden panel trigger. The panel is automatically created when a module position is published to the panel position.

### Hidden panel Example
![Banner map settings](/images/hidden-panel/hidden-panel-example.jpg)