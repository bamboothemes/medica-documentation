---
title: Bottom menu and logo
taxonomy:
    category: docs
---

### Coming Soon