---
title: Frontpage Setup
taxonomy:
    category: docs
---


This section contains information and directions for recreating the display of the Medica frontpage as can be seen on the Medica demo site.
