---
title: Contact Page
taxonomy:
    category: docs
---

The contact page used on the Medica demo site uses the standard Joomla contact layout plus an instance of the Maps2 module published to the banner position.

![Banner map module](/images/contact/medica-contact-page.jpg)

### Settings used for maps2 module
![Banner map settings](/images/contact/contact-map-settings.jpg)
