# v1.2.0
## 07/20/2015

1. [](#new)
    * Updated `highlight.js` to version 8.6
    * Added new themes

# v1.1.0
## 11/30/2014

1. [](#new)
    * ChangeLog started...
