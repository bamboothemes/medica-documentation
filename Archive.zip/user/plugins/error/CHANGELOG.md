# v1.2.2
## 01/06/2015

1. [](#new)
    * Added a default `error.json.twig` file

# v1.2.1
## 11/30/2014

1. [](#new)
    * ChangeLog started...
