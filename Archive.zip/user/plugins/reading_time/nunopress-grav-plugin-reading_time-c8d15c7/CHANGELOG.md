# v1.1.3
## 02/04/2015

1. [](#bugfix)
    * Change name for internal method mergeConfig to mergePluginConfig.

# v1.1.2
## 02/04/2015

1. [](#improved)
    * Update blueprints.yaml.

# v1.1.1
## 01/10/2015

1. [](#improved)
    * Add support for plugin configuration on Admin Plugin.

# v1.1.0
## 01/01/2015

1. [](#new)
    * Changelog started.
    * Remove Twig Extension and change to Simple Filter.
    * Small update to [Blueprint](blueprints.yaml).
