<?php
namespace Grav;


class TestCase extends \PHPUnit_Framework_TestCase
{

}
